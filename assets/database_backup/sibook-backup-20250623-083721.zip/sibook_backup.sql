#
# TABLE STRUCTURE FOR: tb_aplikasi
#

DROP TABLE IF EXISTS `tb_aplikasi`;

CREATE TABLE `tb_aplikasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `telp` varchar(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `alamat` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `logo` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_aplikasi` (`id`, `nama`, `telp`, `email`, `alamat`, `logo`) VALUES (1, 'sibook', '0987654321', 'sibook@unimma.ac.id', 'Jl. Mayjend. Bambang Soegeng Km. 5, Mertoyudan, Magelang 56172', 'Logo-1750653227.png');


#
# TABLE STRUCTURE FOR: tb_backupdb
#

DROP TABLE IF EXISTS `tb_backupdb`;

CREATE TABLE `tb_backupdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `database` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `terdaftar` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_backupdb` (`id`, `idUser`, `database`, `terdaftar`) VALUES (1, 1, 'Oscar Store - Backup Database - 23 June 2025 06:42:58.zip', '2025-06-23 06:42:58');
INSERT INTO `tb_backupdb` (`id`, `idUser`, `database`, `terdaftar`) VALUES (2, 1, 'Oscar Store - Backup Database - 23 June 2025 07:12:25.zip', '2025-06-23 07:12:25');
INSERT INTO `tb_backupdb` (`id`, `idUser`, `database`, `terdaftar`) VALUES (3, 1, 'Oscar Store - Backup Database - 23 June 2025 07:12:56.zip', '2025-06-23 07:12:56');


#
# TABLE STRUCTURE FOR: tb_booking
#

DROP TABLE IF EXISTS `tb_booking`;

CREATE TABLE `tb_booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idRuangan` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `dariJam` time NOT NULL,
  `sampaiJam` time NOT NULL,
  `agenda` varchar(256) NOT NULL,
  `status` varchar(256) NOT NULL,
  `terdaftar` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_booking` (`id`, `idRuangan`, `idUser`, `tanggal`, `dariJam`, `sampaiJam`, `agenda`, `status`, `terdaftar`) VALUES (1, 6, 1, '2025-06-25', '17:00:00', '18:00:00', 'Kelas Pemrogaraman Web 2', 'Diterima', '2025-06-23 10:57:22');


#
# TABLE STRUCTURE FOR: tb_log
#

DROP TABLE IF EXISTS `tb_log`;

CREATE TABLE `tb_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `ipAddress` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `device` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `status` varchar(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `terdaftar` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_log` (`id`, `idUser`, `ipAddress`, `device`, `status`, `terdaftar`) VALUES (1, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'Login', '2025-06-22 18:42:58');
INSERT INTO `tb_log` (`id`, `idUser`, `ipAddress`, `device`, `status`, `terdaftar`) VALUES (2, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'Login', '2025-06-23 07:55:58');


#
# TABLE STRUCTURE FOR: tb_ruangan
#

DROP TABLE IF EXISTS `tb_ruangan`;

CREATE TABLE `tb_ruangan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(256) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `terdaftar` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_ruangan` (`id`, `kode`, `nama`, `terdaftar`) VALUES (5, 'R IF 101', 'Ruang Informatika Lantai 1 Nomor 01', '2025-06-23 10:54:40');
INSERT INTO `tb_ruangan` (`id`, `kode`, `nama`, `terdaftar`) VALUES (6, 'R IF 102', 'Ruang Informatika Lantai 1 Nomor 02', '2025-06-23 10:54:58');


#
# TABLE STRUCTURE FOR: tb_user
#

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `jenisKelamin` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `telp` varchar(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `alamat` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `username` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `password` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `foto` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `skin` varchar(8) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `level` varchar(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `login` varchar(8) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `terdaftar` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_user` (`id`, `nama`, `jenisKelamin`, `telp`, `email`, `alamat`, `username`, `password`, `foto`, `skin`, `level`, `login`, `terdaftar`) VALUES (1, 'Setiya Nugroho', 'Laki-Laki', '085292335357', 'setiya@unimma.ac.id', 'Blabak, Miungkid, Magelang', 'admin', '$2y$10$owHjmzg.7RTtxItuC9j.FOPf4fTPLyVaRPBsqaF7ByLtxN/SZCzsO', 'Profil-1750649874.png', 'blue', 'Administrator', 'Ya', '2023-02-16 10:03:46');
INSERT INTO `tb_user` (`id`, `nama`, `jenisKelamin`, `telp`, `email`, `alamat`, `username`, `password`, `foto`, `skin`, `level`, `login`, `terdaftar`) VALUES (2, 'Setiya', 'Laki-Laki', '08123456789', 'setiya@ummgl.ac.id', 'Blabak', 'setiya', '$2y$10$gFg5h3HnRjF9CBCmORruf.UvgMEvgjj8RNjdCVwQXJ.TF3mLUltYS', 'no-image.png', 'blue', 'User', 'Ya', '2025-06-16 00:49:02');
INSERT INTO `tb_user` (`id`, `nama`, `jenisKelamin`, `telp`, `email`, `alamat`, `username`, `password`, `foto`, `skin`, `level`, `login`, `terdaftar`) VALUES (4, 'Syaifudin', 'Laki-Laki', '0818272343', 'syaifudin1878@magelangkab.go.id', 'Ngluwar, Magelang', 'syaifudin', '$2y$10$h3Qgpg7d.DanyF0EkhI3jeqLnwOZZ8kWdW268OUW2qM6Xdu3QopAK', 'no-image.png', 'blue', 'User', 'Ya', '2025-06-23 11:17:54');


